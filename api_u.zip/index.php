<?php
ob_start();
?>
<!DOCTYPE HTML>
<html>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>API - Login</title>

    <!-- CSS -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    
    <!-- JS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    
    <!--script-->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<SCRIPT LANGUAGE="JavaScript">

function ValidateForm(){
    
	var NUser=document.form.usuario
	var NPass=document.form.password

	if ((NUser.value==null)||(NUser.value=="")){
		alert("Introduzca el Usuario!")
		NUser.focus()
		return false
	}
	
	if ((NPass.value==null)||(NPass.value=="")){
		alert("Introduzca la Contraseña")
		NPass.focus()
		return false
	}	
	
	return true
 }
 

function Login() {
    
try {

var formdata = new FormData();
formdata.append("u", "xx");
formdata.append("p", "xx");

var requestOptions = {
  method: 'POST',
  body: formdata,
  headers: {
    "Content-type": "application/json; charset=UTF-8"
  },
  redirect: 'follow'
};

fetch("http://zwestgroup-001-site3.gtempurl.com/api.php?ep=login", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(function(error){
	alert("Error en las Credenciales");
	document.getElementById('acceso').value = 1;
	return false;
  });

} catch (e){
	alert("Error en las Credenciales")
	return false
}

}

function longinAjax (){

	try {

	$.ajax({
    data: {"u" : "valor1", "p" : "valor2"},
    type: "POST",
    dataType: "json",
    url: "https://zwestgroup-001-site3.gtempurl.com/api.php?ep=login",
})
 .done(function( data, textStatus, jqXHR ) {
     if ( console && console.log ) {
         console.log( "La solicitud se ha completado correctamente." );
		 alert("correcto");
     }
 })
 .fail(function( jqXHR, textStatus, errorThrown ) {
     if ( console && console.log ) {
         console.log( "La solicitud a fallado: " +  textStatus);
		 alert(textStatus);
     }
});

	} catch(e){
		alert(e);
	}

}
</script>


<style type="text/css">
.bg-primary {
    background-color: transparent !important;
    padding: 25px;
}	
</style>

</head>

<body >

<?php 
    if (!isset($_GET['ingr'])) {
		if (isset($_GET['error']) && $_GET['error'] == '1') {    

	$respuesta = '<span class="_text01"><font color="#FF0000"><b>ERROR: </b>Credenciales Incorrectas</font></span>';
	
?>	

<?php } ?>


	<header>
	    
		<nav class="navbar navbar-dark bg-primary navbar-fixed-top">
		    
		  <div class="container-fullwidth">
		      
		    <div class="navbar-header"></div>
		    
		  </div>
		  
		</nav>
		
	</header>


	<div class="login">
	    
		<form name="form" class="form" action="index.php?ingr=index"  method="post" onSubmit="return longinAjax()">

    		<div class="header">
    			    
                <h2>API Login</h2>
    			    
    		</div>
    			
			<div class="content">

			    <input type="text" class="input username inp-text" placeholder="Usuario" required="" name="usuario" id="usuario" size="8" maxlength="8"  title="">
			
			    <input type="password" class="input password inp-text" placeholder="Contraseña" required="" name="password" id="password"  title=""> 
			
			</div>
			
			<div class="login_button">
			   
    			<button class="button" type="submit">Entrar</button>
    			
    			<div id="respuesta"> <?php echo $respuesta; ?> </div>
    
    			<input type="hidden" id="acceso" name="acceso" value="">

			</div>

<?php
			
} else if (isset($_GET['ingr']) && $_GET['ingr'] == 'index') { 

$usuario = $_POST["usuario"];
$password = $_POST["password"];

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://zwestgroup-001-site3.gtempurl.com/api.php?ep=login',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('u' => $usuario,'p' => $password),
));

$response = curl_exec($curl);

curl_close($curl);


if ($response=='null'){


header("Location: api_login.php?id=".$usuario);  
exit();


}else {


header("Location: index.php?error=1");
exit();


}

}

?>
			
	    </form>

    </div>

</body>
</html>