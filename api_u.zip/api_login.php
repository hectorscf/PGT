<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Meta -->
    <meta name="description" content="">
    <meta name="author" content="">
    <title>API - Juegos</title>
    
    <!-- vendor css -->
    <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="lib/Ionicons/css/ionicons.css" rel="stylesheet">
    <link href="lib/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">
    
    <!--CSS -->
    <link rel="stylesheet" href="css/starlight.css">
    <link  href="fancybox/dist/jquery.fancybox.min.css" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    
    <!-- JS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    
    <!--script-->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    
    <script type="text/javascript">
     var $= jQuery.noConflict();
    </script>
    
    <style>

    </style>
</head>


<script>
    
function display()
{

try {

var formdata = new FormData();

var requestOptions = {
  method: 'GET'
};

fetch("http://zwestgroup-001-site3.gtempurl.com/api.php?ep=juegos", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(function(error){
    alert(error);
  });
  
}catch(e){
  alert(e);
}
}

$(document).ready(function() {

$("a#single_image").fancybox();

$("a#inline").fancybox({
  'hideOnContentClick': true
});

$("a.group").fancybox({
  'transitionIn'	:	'elastic',
  'transitionOut'	:	'elastic',
  'speedIn'		:	600, 
  'speedOut'		:	200, 
  'overlayShow'	:	false
});

});
</script>


<body> 

<!-- ########## START: LEFT PANEL ########## -->
  <div class="sl-logo"><a href="#">LOGO</a></div>
    <div class="sl-sideleft">
      <br>
      <div class="sl-sideleft-menu">

        
        <a href="index.php" class="sl-menu-link">
          <div class="sl-menu-item">
            <i class="menu-item-icon icon ion-log-out tx-24"></i>
            <span class="menu-item-label">Salir</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
      </div><!-- sl-sideleft-menu -->
      <br>
    </div><!-- sl-sideleft -->
    <!-- ########## END: LEFT PANEL ########## -->

    <!-- ########## START: HEAD PANEL ########## -->
    <div class="sl-header">
      <div class="sl-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href="#"><i class="icon ion-navicon-round"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href="#"><i class="icon ion-navicon-round"></i></a></div>
      </div><!-- sl-header-left -->

      <div class="sl-header-right">
        <div class="navicon-right">
          <a id="" href="logout.php" class="pos-relative">
            <span>SALIR</span> <i class="icon ion-log-out"></i>
          </a>
        </div><!-- navicon-right -->
      </div><!-- sl-header-right -->
    </div><!-- sl-header -->
    <!-- ########## END: HEAD PANEL ########## -->

    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
      <nav class="breadcrumb sl-breadcrumb">
        <span class="breadcrumb-item active">
        <?php
            echo "NOMBRE DEL USUARIO: <strong>".$_GET["id"]."</strong>";
        ?>
        </span>
      </nav>
      <div class="sl-pagebody">
        <div class="row row-sm mg-t-20">
          <div class="col-xl-12">
            <div class="card overflow-hidden">
              <div class="card-header bg-transparent d-sm-flex align-items-center justify-content-between">
                <div class="mg-b-20 mg-sm-b-0">
                  <h6 class="card-title mg-b-5 tx-13 tx-uppercase tx-bold tx-spacing-1">API Juegos</h6>
                  <span class="d-block tx-12"></span>
                </div>
              </div><!-- card-header -->
              <div class="card-body pd-0 bd-color-gray-lighter">
                <div class="tx-center">
                  <div class="col-12 col-sm-12 pd-y-20 tx-left">

<?php
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://zwestgroup-001-site3.gtempurl.com/api.php?ep=juegos',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$response = curl_exec($curl);

curl_close($curl);

$json_decoded = json_decode($response);

$temp = "<table>";
$temp .= "<tr><th>Eliminar</th>";
$temp .= "<th>Editar</th>"; 
$temp .= "<th>Id</th>";
$temp .= "<th>Nombre</th>";
$temp .= "<th>Codigo</th>";
$temp .= "<th>Resumen</th>";
$temp .= "<th>Imagen</th>";
$temp .= "<th>Activo</th></tr>";

foreach ($json_decoded as $name => $obj) {
  $temp .= "<tr>";
  $temp .= "<td><a class='icon_f' href='#'><i class='fa fa-trash' aria-hidden='true'></i></a></td>";
  $temp .= "<td><a class='icon_f' href='#'><i class='fa fa-pencil' aria-hidden='true'></i></a></td>";
  $temp .= "<td>" . $obj->id . "</td>";
  $temp .= "<td>" .$obj->nombre . "</td>";
  $temp .= "<td>" .$obj->codigo  . "</td>";
  $temp .= "<td>" . $obj->resumen . "</td>";
  $temp .= "<td><a data-fancybox='gallery' href='$obj->imagen'><img src='$obj->imagen'></a></td>";
  $temp .= "<td>" . $obj->activo . "</td>";
  $temp .= "</tr>";
  }
   
$temp .= "</table>";

echo $temp;

?>



                    <!--END PDF VIEWER-->

                  </div><!-- col-4 -->
                </div><!-- row -->
              </div><!-- card-body -->
            </div><!-- card -->
          </div><!-- col-8 -->

        
        </div><!-- row -->
      </div><!-- sl-pagebody -->

      <footer class="sl-footer">
        <div class="footer-left">
          <div class="mg-b-2">Copyright &copy; 2021 Todos los Derechos Reservados.</div>
        </div>
      </footer>
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->

    <script src="lib/jquery/jquery.js"></script>
    <script src="lib/jquery-ui/jquery-ui.js"></script>
    <script type="text/javascript" src="fancybox/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <script src="fancybox/dist/jquery.fancybox.min.js"></script>

  </body>

</html>